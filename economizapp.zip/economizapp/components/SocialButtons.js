import React from 'react';
import { View, Linking, TouchableOpacity, StyleSheet } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const SocialButtons = () => {
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => Linking.openURL('https://instagram.com')} style={styles.button}>
        <FontAwesome name="instagram" size={32} color="#C13584" />
      </TouchableOpacity>
      <TouchableOpacity onPress={() => Linking.openURL('https://facebook.com')} style={styles.button}>
        <FontAwesome name="facebook" size={32} color="#3b5998" />
      </TouchableOpacity>
      <TouchableOpacity onPress={() => Linking.openURL('https://wa.me/5500000000000')} style={styles.button}>
        <FontAwesome name="whatsapp" size={32} color="#25D366" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  button: {
    paddingHorizontal: 5,
  },
});

export default SocialButtons;
