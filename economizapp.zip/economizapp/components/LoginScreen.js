import React, { useState } from 'react';
import * as FileSystem from 'expo-file-system';
import {
  View, Text, TextInput, StyleSheet, Alert,
  TouchableOpacity, Image, ImageBackground
} from 'react-native';

export default function LoginScreen({ navigation }) {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);

  const fazerLogin = async () => {
    const caminhoArquivo = FileSystem.documentDirectory + 'dadosUsuario.json';
    try {
      const info = await FileSystem.getInfoAsync(caminhoArquivo);

      if (!info.exists) {
        Alert.alert('Aviso', 'Nenhum usuário cadastrado. Redirecionando...');
        navigation.navigate('Cadastro');
        return;
      }

      const conteudo = await FileSystem.readAsStringAsync(caminhoArquivo);
      const dadosUsuario = JSON.parse(conteudo);

      if (!dadosUsuario.nome || !dadosUsuario.senha) {
        Alert.alert('Erro', 'Dados do usuário estão corrompidos. Cadastre novamente.');
        return;
      }

      if (usuario === dadosUsuario.nome && senha === dadosUsuario.senha) {
        navigation.navigate('Home');
      } else {
        Alert.alert('Erro', 'Usuário ou senha inválidos.');
      }

    } catch (error) {
      console.error('Erro ao ler arquivo:', error);
      Alert.alert('Erro', 'Não foi possível acessar os dados do usuário.');
    }
  };

  return (
    <ImageBackground
      //source={require('./background/logo.png')}
      style={styles.background}
      resizeMode="contain"
    >
      <View style={styles.overlay}>
        <Text style={styles.titulo}>Login</Text>

        <TextInput
          placeholder="Usuário"
          style={styles.input}
          value={usuario}
          onChangeText={setUsuario}
        />

        <View style={styles.senhaContainer}>
          <TextInput
            placeholder="Senha"
            style={[styles.input, { flex: 1 }]}
            secureTextEntry={!mostrarSenha}
            value={senha}
            onChangeText={setSenha}
          />
          <TouchableOpacity onPress={() => setMostrarSenha(!mostrarSenha)}>
            <Text style={styles.toggleSenha}>
              {mostrarSenha ? 'Ocultar' : 'Mostrar'}
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={fazerLogin} style={styles.botao}>
          <Text style={styles.botaoTexto}>Entrar</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Cadastro')}>
          <Text style={styles.linkCadastro}>Não tem uma conta? Cadastre-se</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.logoContainer}>
        <Image
          source={require('./background/logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    justifyContent: 'center',
    padding: 20,
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  senhaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  toggleSenha: {
    marginLeft: 10,
    color: '#007bff',
    fontWeight: 'bold',
  },
  botao: {
    backgroundColor: '#007bff',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  botaoTexto: {
    color: '#fff',
    fontWeight: 'bold',
  },
  linkCadastro: {
    color: '#007bff',
    textAlign: 'center',
    marginTop: 15,
  },
  logoContainer: {
    position: 'absolute',
    bottom: 20,
    alignSelf: 'center',
    width: 150,
    height: 150,
  },
  logo: {
    width: '100%',
    height: '100%',
  },
});
