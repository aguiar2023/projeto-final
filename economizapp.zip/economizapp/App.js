import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import SplashScreen from './components/SplashScreen';
import LoginScreen from './components/LoginScreen';
import CadastroUsuarioScreen from './components/CadastroUsuarioScreen';
import HomeScreen from './components/HomeScreen';
import ConfiguracoesScreen from './components/ConfiguracoesScreen';
import ListaComprasScreen from './components/ListaComprasScreen';
import CadastroProdutoScreen from './components/CadastroProdutoScreen';
import FiltroProdutoScreen from './components/FiltroProdutoScreen';
import MapaSupermercadoScreen from './components/MapaSupermercadoScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Splash"
        screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Cadastro" component={CadastroUsuarioScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Configuracoes" component={ConfiguracoesScreen} />
        <Stack.Screen name="ListaCompras" component={ListaComprasScreen} />
        <Stack.Screen
          name="CadastroProduto"
          component={CadastroProdutoScreen}
        />
        <Stack.Screen name="FiltroProduto" component={FiltroProdutoScreen} />
        <Stack.Screen
          name="MapaSupermercado"
          component={MapaSupermercadoScreen}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
